﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            txtImc.Clear();

            if (!Double.TryParse(mskbxPeso.Text, out peso) ||
                !Double.TryParse(mskbxAltura.Text, out altura) ||
                peso <= 0 || altura <=0)
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Valor de altura inválida");
                    mskbxAltura.Focus();
                }
                if (peso <= 0)
                {
                    MessageBox.Show("Valor de peso inválido");
                    mskbxPeso.Focus();
                }
            }
            else
            {
                imc = Math.Round(peso / Math.Pow(altura, 2), 1);

                if (imc < 18.5)
                {
                    txtImc.Text = imc + " - Magreza";
                }
                else if (imc >= 18.5 && imc < 25)
                {
                    txtImc.Text = imc + " - Normal";
                }
                else if (imc >= 25 && imc < 30)
                {
                    txtImc.Text = imc + " - Sobrepeso";
                }
                else if (imc >= 30 && imc < 40)
                {
                    txtImc.Text = imc + " - Obesidade";
                }
                else if (imc >= 40)
                {
                    txtImc.Text = imc + " - Obesidade Grave";
                }
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                errorProvider2.SetError(mskbxAltura, "Altura Inválida");
            }
            else
            {
                errorProvider2.SetError(mskbxAltura, "");
            }
        }

        private void Sair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair da aplicação?", "Saída",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtImc.Clear();
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                errorProvider1.SetError(mskbxPeso, "Peso Inválido");
            }
            else
            {
                errorProvider1.SetError(mskbxPeso, "");
            }
        }
    }
}
