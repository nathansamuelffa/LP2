﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormTriangulo : Form
    {
        double ladoA, ladoB, ladoC;

        public FormTriangulo()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) || ladoA <= 0)
            {
                errorProvider1.SetError(txtLadoA, "Lado A invalido");
            }
            else
            {
                errorProvider1.SetError(txtLadoA, "");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB) || ladoB <= 0)
            {
                errorProvider2.SetError(txtLadoB, "Lado B invalido");
            }
            else
            {
                errorProvider2.SetError(txtLadoB, "");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            
                if (!Double.TryParse(txtLadoC.Text, out ladoC) || ladoC <= 0)
                {
                    errorProvider3.SetError(txtLadoC, "Lado C invalido");
                }
                else
                {
                    errorProvider3.SetError(txtLadoC, "");
                }
           
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) ||
                !Double.TryParse(txtLadoB.Text, out ladoB) ||
                !Double.TryParse(txtLadoC.Text, out ladoC) ||
                ladoA <= 0 || ladoB <= 0 || ladoC <= 0)
            {
                if (ladoA <= 0)
                {
                    MessageBox.Show("Valor do lado A inválido");
                    txtLadoA.Focus();
                }
                if (ladoB <= 0)
                {
                    MessageBox.Show("Valor do lado B inválido");
                    txtLadoB.Focus();
                }
                if (ladoC <= 0)
                {
                    MessageBox.Show("Valor do lado C inválido");
                    txtLadoC.Focus();
                }
            }
            else
            {
                if ((ladoA < ladoB + ladoC) && (ladoA > Math.Abs(ladoB - ladoC)) && 
                    (ladoB < ladoA + ladoC) && (ladoB > Math.Abs(ladoA - ladoC)) &&
                    (ladoC < ladoA + ladoB) && (ladoC > Math.Abs(ladoA - ladoB)))
                {
                    if ((ladoA == ladoC) && (ladoB == ladoC))
                    {
                        MessageBox.Show("Equilátero");
                    }

                    else if ((ladoA == ladoB) || (ladoA == ladoC) || (ladoB == ladoC))
                    {
                        MessageBox.Show("Isóceles");
                    }

                    else
                    {
                        MessageBox.Show("Escaleno");
                    }
                }

                else
                {
                    MessageBox.Show("Isto não é um triângulo");
                }

            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair da aplicação?", "Saída",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question)
               == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
