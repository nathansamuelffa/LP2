﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int tamanho = rhctxtFrase.Text.Length, contaNum = 0, i = 0;

            while (i < tamanho)
            {
                if (Char.IsNumber(rhctxtFrase.Text[i]))
                {
                    contaNum++;
                }

                i++;
            }
            MessageBox.Show($"Quantidade de números: {contaNum}");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = -1;

            for(int i = 0; i < rhctxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rhctxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            if (posicao == -1)
            {
                MessageBox.Show("Não há espaço em branco");
            }
            else
            {
                MessageBox.Show($"Posição 1º espaço em branco: {posicao}");
            }
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int tamanho = rhctxtFrase.Text.Length, contaLetra = 0;

            foreach (char c in rhctxtFrase.Text)
            {
                if (Char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"Quantidade de letras: {contaLetra}");
        }
    }
}
