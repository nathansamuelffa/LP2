﻿using System;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int Numero1, Numero2;

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
                if (!Int32.TryParse(txtNumero1.Text, out Numero1) || Numero1 < 0)
                {
                     if (!Int32.TryParse(txtNumero1.Text, out Numero1))
                     {
                        errorProvider1.SetError(txtNumero1, "Numero 1 deve ser inteiro");
                     }
                     else if (Numero1 < 0)
                     {
                        errorProvider1.SetError(txtNumero1, "Numero 1 não pode ser menor que zero");
                     }
                }
                else
                {
                    errorProvider1.SetError(txtNumero1, "");
                }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Int32.TryParse(txtNumero2.Text, out Numero2) || Numero2 < Numero1 || Numero2 < 0)
            {
                if (!Int32.TryParse(txtNumero2.Text, out Numero2))
                {
                    errorProvider2.SetError(txtNumero2, "Numero 2 deve ser inteiro");
                }
                else if (Numero2 < 0)
                {
                    errorProvider2.SetError(txtNumero2, "Numero 2 não pode ser menor que zero");
                }
                else if (Numero2 < Numero1)
                {
                    errorProvider2.SetError(txtNumero2, "Numero 1 não pode ser maior que o Numero 2");
                }

            }
            else
            {
                errorProvider2.SetError(txtNumero2, "");
            }
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!Int32.TryParse(txtNumero1.Text, out Numero1) ||
                !Int32.TryParse(txtNumero2.Text, out Numero2) ||
                Numero2 < Numero1 || Numero2 < 0 || Numero2 < 0)
            {
                if (!Int32.TryParse(txtNumero1.Text, out Numero1) || !Int32.TryParse(txtNumero2.Text, out Numero2))
                {
                    MessageBox.Show("Entrada para um dos Numeros não é um inteiro");
                }
                else if (Numero2 < Numero1)
                {
                    MessageBox.Show("Numero 1 não pode ser maior que o Numero 2");
                }
                else
                {
                    MessageBox.Show("Entrada para um dos Numeros é inválida");
                }
            }

            else
            {
                Random objAlert = new Random();

                double sorteado = objAlert.Next(Numero1, Numero2);

                MessageBox.Show($"O numero sorteado é: {sorteado}");
            }
        }
    }
}
