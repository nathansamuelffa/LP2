﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    internal class Mensalista : Empregado //herança
    {

        public Double SalarioMensal { get; set; }

        //sobrescrever o metodo
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

    }
}
