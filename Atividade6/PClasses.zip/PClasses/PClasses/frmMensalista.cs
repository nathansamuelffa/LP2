﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnMensalista_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            //set
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEnt.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalarioMensal.Text);

            //get

            MessageBox.Show($"Nome: {objMensalista.NomeEmpregado}\n" +
                            $"Matricula:  {objMensalista.Matricula}\n" +
                            $"Tempo de Trabalho: {objMensalista.TempoTrabalho()}\n" +
                            $"Salário Final: R$ {objMensalista.SalarioBruto().ToString("N2")}");
        }
    }
}
