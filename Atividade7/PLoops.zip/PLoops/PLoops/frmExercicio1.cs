﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    contador++;
                }
            }

            if (contador == 0)
            {
                MessageBox.Show("Não há espaço em branco");
            }
            else
            {
                MessageBox.Show($"Número de espaços em branco é: {contador}");
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int contador = 0, i = 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if ((rchtxtFrase.Text[i]) == 'R' || (rchtxtFrase.Text[i]) == 'r')
                {
                    contador++;
                }

                i++;
            }

            if (contador == 0)
            {
                MessageBox.Show("Não há a letra R");
            }
            else
            {
                MessageBox.Show($"Número de letras R é: {contador}");
            }
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int i = 1;
            int contPares = 0;

            while (i < rchtxtFrase.Text.Length)
            {
                if ((rchtxtFrase.Text[i]) == (rchtxtFrase.Text[i - 1]))
                {
                    contPares++;
                }

                i++;
            }

            if (contPares == 0)
            {
                MessageBox.Show("Não há pares de letras");
            }
            else
            {
                MessageBox.Show($"Exitem {contPares} pares de letras");
            }
        }
    }
}
