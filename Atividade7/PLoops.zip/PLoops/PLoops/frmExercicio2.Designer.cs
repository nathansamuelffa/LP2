﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumeroH = new System.Windows.Forms.TextBox();
            this.txtNumeroN = new System.Windows.Forms.TextBox();
            this.btnGerarH = new System.Windows.Forms.Button();
            this.lblNumeroH = new System.Windows.Forms.Label();
            this.lblNumeroN = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNumeroH
            // 
            this.txtNumeroH.Location = new System.Drawing.Point(296, 234);
            this.txtNumeroH.Name = "txtNumeroH";
            this.txtNumeroH.ReadOnly = true;
            this.txtNumeroH.Size = new System.Drawing.Size(209, 22);
            this.txtNumeroH.TabIndex = 0;
            // 
            // txtNumeroN
            // 
            this.txtNumeroN.Location = new System.Drawing.Point(296, 115);
            this.txtNumeroN.Name = "txtNumeroN";
            this.txtNumeroN.Size = new System.Drawing.Size(209, 22);
            this.txtNumeroN.TabIndex = 1;
            // 
            // btnGerarH
            // 
            this.btnGerarH.Location = new System.Drawing.Point(314, 333);
            this.btnGerarH.Name = "btnGerarH";
            this.btnGerarH.Size = new System.Drawing.Size(177, 56);
            this.btnGerarH.TabIndex = 3;
            this.btnGerarH.Text = "Gerar H";
            this.btnGerarH.UseVisualStyleBackColor = true;
            this.btnGerarH.Click += new System.EventHandler(this.btnGerarH_Click);
            // 
            // lblNumeroH
            // 
            this.lblNumeroH.AutoSize = true;
            this.lblNumeroH.Location = new System.Drawing.Point(293, 215);
            this.lblNumeroH.Name = "lblNumeroH";
            this.lblNumeroH.Size = new System.Drawing.Size(68, 16);
            this.lblNumeroH.TabIndex = 4;
            this.lblNumeroH.Text = "Número H";
            // 
            // lblNumeroN
            // 
            this.lblNumeroN.AutoSize = true;
            this.lblNumeroN.Location = new System.Drawing.Point(293, 96);
            this.lblNumeroN.Name = "lblNumeroN";
            this.lblNumeroN.Size = new System.Drawing.Size(68, 16);
            this.lblNumeroN.TabIndex = 5;
            this.lblNumeroN.Text = "Número N";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblNumeroN);
            this.Controls.Add(this.lblNumeroH);
            this.Controls.Add(this.btnGerarH);
            this.Controls.Add(this.txtNumeroN);
            this.Controls.Add(this.txtNumeroH);
            this.Name = "frmExercicio2";
            this.Text = "Gerar o número H";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumeroH;
        private System.Windows.Forms.TextBox txtNumeroN;
        private System.Windows.Forms.Button btnGerarH;
        private System.Windows.Forms.Label lblNumeroH;
        private System.Windows.Forms.Label lblNumeroN;
    }
}