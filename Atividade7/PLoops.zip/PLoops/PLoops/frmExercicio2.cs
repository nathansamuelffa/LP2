﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            int N;

            if (!Int32.TryParse(txtNumeroN.Text, out N) || N < 0)
            {
                MessageBox.Show("Entrada para um dos Numero N é inválida ou N é menor que 0 (zero)");
            }
            else
            {
                double H = 0;

                for (int i = 1; i <= N; i++)
                {
                    H += 1 / (double)i;
                }

                txtNumeroH.Text = H.ToString();
            }
        }
    }
}
