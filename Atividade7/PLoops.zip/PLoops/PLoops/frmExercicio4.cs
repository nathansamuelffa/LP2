﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalculaSalario_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int producao;
            double salarioBase;
            double gratificacao;

            if (!Int32.TryParse(txtProducao.Text, out producao) ||
                !Double.TryParse(txtSalario.Text, out salarioBase) ||
                !Double.TryParse(txtGratificacao.Text, out gratificacao) ||
                producao < 0 || salarioBase < 0)
            {
                if (!Int32.TryParse(txtProducao.Text, out producao))
                {
                    MessageBox.Show("Produção deve ser um inteiro maior que 0");
                }

                if (!Double.TryParse(txtSalario.Text, out salarioBase))
                {
                    MessageBox.Show("Salário deve ser um real (X,00) maior que 0");
                }
                if (!Double.TryParse(txtGratificacao.Text, out gratificacao))
                {
                    MessageBox.Show("Gratificação deve ser um real (X,00)");
                }
            }

            else
            {

                int B = producao >= 100 ? 1 : 0;
                int C = producao >= 120 ? 1 : 0;
                int D = producao >= 150 ? 1 : 0;

                double salarioBruto = salarioBase + salarioBase * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;

                if (salarioBruto > 7000 && !(producao >= 150 && gratificacao > 0))
                {
                    salarioBruto = 7000;
                }

                MessageBox.Show($"Funcionário: {nome}\nMatrícula: {matricula}\nSalário Bruto: {salarioBruto:C2}", "Resultado");
            }
        }
    }
}
