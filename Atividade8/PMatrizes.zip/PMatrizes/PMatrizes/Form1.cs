﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;
using System.Net.Http.Headers;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";

            foreach(int j in vetor)
            {
                auxiliar += j + "\n";
            }

            MessageBox.Show(auxiliar, "Reverso");
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();
                obj5.Show();
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                obj4.Show();
            }
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            string aux = "";
            int aluno, nota;

            for (aluno = 0; aluno < 2; aluno++)
            {

                for (nota = 0; nota < 3; nota++)
                {
                    aux = Interaction.InputBox($"Digite {nota + 1}º nota do aluno {aluno + 1}", "Entrada de dados");

                    if (!Double.TryParse(aux, out notas[aluno, nota]) || notas[aluno, nota] < 0)
                    {
                        MessageBox.Show("Nota Inválida");
                        nota--;
                    }
                    else
                    {
                        media[aluno] += notas[aluno, nota];
                    }
                }

                media[aluno] /= 3;
                MessageBox.Show($"Aluno {aluno+1} tem média: {media[aluno]}");
            }

        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList listinha = new ArrayList() 
            { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };

            listinha.Remove("Otávio");

            string aux = "";
            foreach (string nomes in listinha)
            {
                aux += nomes + "\n";
            }

            MessageBox.Show(aux, "Nomes da listinha");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
