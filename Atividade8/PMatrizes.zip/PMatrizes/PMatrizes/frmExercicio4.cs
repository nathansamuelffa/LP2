﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] qtdeCaracteres = new int[10];

            for (int i = 0; i < nomes.Length; i++)
            {
                nomes[i] = Interaction.InputBox
                ($"Digite o nome completo da {i + 1}ª pessoa:", "Entrada de Nomes");

                if (nomes[i] == "")
                {
                    MessageBox.Show("Nome Inválido");
                    i--;
                }

                /*if (string.IsNullOrEmpty(nomes[i])) // se quiser para sair por completo
                {
                    DialogResult result = MessageBox.Show
                    ("Deseja realmente sair?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        this.Close();
                        return;
                    }
                    else
                    {
                        i--;
                    }
                }*/

                else
                {
                    qtdeCaracteres[i] = 0;

                    //qtdeCaracteres[i] = nomes[i].Replace(" ", "").Length; //ou assim

                    foreach (char c in nomes[i]) //ou assim
                    {
                        if (!char.IsWhiteSpace(c))
                        {
                            qtdeCaracteres[i]++;
                        }
                    }
                }
            }

            lstboxResultado.Items.Clear();
            for (int i = 0; i < nomes.Length; i++)
            {
                lstboxResultado.Items.Add($"{nomes[i]} tem {qtdeCaracteres[i]} caracteres");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
