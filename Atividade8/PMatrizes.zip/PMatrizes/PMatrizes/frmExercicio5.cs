﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[,] respostas = new char[4, 10];
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };

            lstboxResultado.Items.Clear();

            for (int aluno = 0; aluno < respostas.GetLength(0); aluno++)
                for (int questao = 0; questao < respostas.GetLength(1); questao++)
                {
                    char resposta;

                    string entrada = Interaction.InputBox
                    ($"Aluno {aluno + 1} - Digite a resposta para a questão {questao + 1}:", "Entrada de Respostas");

                    if (string.IsNullOrEmpty(entrada) || !char.TryParse(entrada, out resposta) ||
                        char.ToUpper(resposta) < 'A' || char.ToUpper(resposta) > 'E')
                    {
                        MessageBox.Show("Resposta Inválida. Digite uma letra entre A e E.");
                        questao--;
                    }
                    else
                    {
                        respostas[aluno, questao] = char.ToUpper(resposta);
                    }

                }

            for (int aluno = 0; aluno < respostas.GetLength(0); aluno++)
                for (int questao = 0; questao < respostas.GetLength(1); questao++)
                {
                    bool acertou = respostas[aluno, questao] == gabarito[questao];

                    lstboxResultado.Items.Add
                    ($"Aluno {aluno + 1} {/*ternário (v) (f)*/ (acertou ? "acertou" : "errou")} questão {questao + 1}: era {gabarito[questao]} e escolheu {respostas[aluno, questao]}");
                }
        }
    }
}
