﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482413023
{
    public partial class formSobre : Form
    {
        public formSobre()
        {
            InitializeComponent();
        }
    }
}
