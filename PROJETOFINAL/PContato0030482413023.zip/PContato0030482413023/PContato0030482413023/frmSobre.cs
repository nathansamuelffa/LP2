﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace PContato0030482413023
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();

            this.Icon = SystemIcons.Information;
        }
    }
}
